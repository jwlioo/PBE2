package com.senai.cadastropessoa.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "tb_cadastro_pessoa")
public class CadastroPessoa {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private Long idPessoa;
	
	@Column ( name = "nome_pessoa")
	private String nomePessoaAtributo;
	
	@Column (name = "idade")
	private int idadePessoaAtributo;
	
	
	
	CadastroPessoa(){
		
	}
	
	CadastroPessoa(Long idPessoaParametro, String nomePessoaParametro, int idadePessoaParametro){
		this.idPessoa = idPessoaParametro;
		this.nomePessoaAtributo = nomePessoaParametro;
		this.idadePessoaAtributo = idadePessoaParametro;
		
	}
	
	public Long getId() {
		return idPessoa;
		
	}
	
	public void setId(Long idPessoaParametroSet) {
		this.idPessoa = idPessoaParametroSet;
	}
	public String GetNomePessoaGetter() {
		return nomePessoaAtributo;
		
	}
	public void setNomePessoaSetter(String nomePessoaParametroSet) {
		this.nomePessoaAtributo = nomePessoaParametroSet;
		
	}
	public int getIdadePessoaGetter() {
		return idadePessoaAtributo;
	}
	
	public void setIdadePessoaSetter(int idadePessoaParametroSet){
		this.idadePessoaAtributo = idadePessoaParametroSet;
		
	}

}
