package com.senai.cadastropessoa.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senai.cadastropessoa.entities.CadastroPessoa;
import com.senai.cadastropessoa.repositories.CadastroPessoaRepository;

@Service
public class CadastroPessoaService  {
	
	
	@Autowired
	private CadastroPessoaRepository objetoCadastroPessoa;
	
	public CadastroPessoa salvarCadastroPessoa(CadastroPessoa cadastroPessoaParametro) {
		
		return objetoCadastroPessoa.save(cadastroPessoaParametro);
		
	}
	public List<CadastroPessoa>  buscarTodoCadastroPessoa(){
		return objetoCadastroPessoa.findAll();
		
		
	}
}
