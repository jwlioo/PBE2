package com.senai.cadastropessoa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.cadastropessoa.entities.CadastroPessoa;

public interface CadastroPessoaRepository extends JpaRepository<CadastroPessoa, Long> {
	

}
