// Aguarda o carregamento da página
document.addEventListener("DOMContentLoaded", function() {

	// Seleciona o formulário pelo ID
	const form = document.getElementById("formCadastroJogo");

	// Adiciona um evento de submit no formulário
	form.addEventListener("submit", function(event) {
		event.preventDefault(); // Impede o envio padrão do formulário

		// Captura os valores digitados nos campos

		const nomeJogo = document.getElementById("nomeJogo").value;
		const anoLancamento = document.getElementById("anoLancamento").value;

		

		// Envia os dados para o backend usando fetch
		fetch('http://localhost:8080/jogos', { // <-- URL do seu backend Spring Boot
			method: 'POST', // Método HTTP
			headers: {
				'Content-Type': 'application/json' // Tipo de conteúdo enviado
			},
			body: JSON.stringify({
				nomeJogo,
                anoLancamento,

				
			})
		})
			.then(response => {
				if (!response.ok) {
					throw new Error('Erro ao cadastrar jogo');
				}
				return response.json(); // Pega o corpo da resposta (esperando que venha o objeto com id)
			})
            .then(data => {
                // Redireciona para jogo.html após cadastro bem-sucedido
                window.location.href = "jogo.html";
            })
			.then(data => {
				// Armazena o ID da pessoa no localStorage
				localStorage.setItem('id', data.id); // Supondo que o backend retorne { id: 1, ... }

			})

	})
		
});