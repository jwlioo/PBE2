document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("formCadastro");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        const nome = document.getElementById("nome").value;
        const idade = document.getElementById("idade").value;

        fetch('http://localhost:8080/cadastrojogadores', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nome, idade })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao cadastrar jogador');
            }
            return response.json();
        })
        .then(data => {
            // Redireciona para jogo.html após cadastro bem-sucedido
            window.location.href = "jogo.html";
        })
        .catch(error => {
            console.error('Erro no cadastro de jogadores:', error);
            alert('Falha ao cadastrar jogador. Tente novamente.');
        });
    });
});