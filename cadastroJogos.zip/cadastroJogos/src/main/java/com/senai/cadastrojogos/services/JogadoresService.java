package com.senai.cadastrojogos.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senai.cadastrojogos.entities.Jogadores;
import com.senai.cadastrojogos.repositories.JogadoresRepository;

@Service
public class JogadoresService {

    @Autowired
    private JogadoresRepository jogadoresRepository;

    // Salvar jogador
    public Jogadores salvar(Jogadores jogador) {
        return jogadoresRepository.save(jogador);
    }

    // Buscar jogador por ID
    public Jogadores buscarPorId(Long id) {
        Optional<Jogadores> jogador = jogadoresRepository.findById(id);
        return jogador.orElse(null); // ou lançar uma exceção personalizada, se preferir
    }

    // Excluir jogador por ID
    public boolean excluir(Long id) {
        if (jogadoresRepository.existsById(id)) {
            jogadoresRepository.deleteById(id);
            return true;
        }
        return false;
    }
}