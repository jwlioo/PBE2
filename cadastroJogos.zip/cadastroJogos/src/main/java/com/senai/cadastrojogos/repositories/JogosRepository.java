package com.senai.cadastrojogos.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.cadastrojogos.entities.Jogos;

public interface JogosRepository extends JpaRepository<Jogos, Long> {
}