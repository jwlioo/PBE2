package com.senai.cadastrojogos.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Jogos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nomeJogo")
    private String nomeJogo;

    @Column(name = "anoLancamento")
    private String anoLancamento;

   

    @ManyToOne
    @JoinColumn(name = "jogadores_id")
    private Jogadores jogadores;
    
    public Jogos() {
    }

    public Jogos(String nomeJogo, String anoLancamento) {
        this.nomeJogo = nomeJogo;
        this.anoLancamento = anoLancamento;
    }
    
    

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
    	this.id = id;
    }
    
    public String getNomeJogo() {
        return nomeJogo;
    }

    public void setNomeJogo(String nomeJogo) {
        this.nomeJogo = nomeJogo;
    }

    public String getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(String anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

}
