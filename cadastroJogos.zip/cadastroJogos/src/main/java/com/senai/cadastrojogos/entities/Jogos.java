package com.senai.cadastrojogos.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

@Entity
public class Jogos {
	
	

    @Column(name = "nomeJogo")
    private String nomeJogo;

    @Column(name = "anoLancamento")
    private String anoLancamento;
    
    @OneToMany
    @JoinColumn(name = "idJogadores", nullable = false)
    private Jogos idJogadores;
    
    
    public Jogos() {
  
    }
    
    public Jogos(String nomeJogo, String anoLancamento) {
    	this.nomeJogo = nomeJogo;
    	this.anoLancamento = anoLancamento;
    	
    }

    
    // Getters & Setters
	public String getNomeJogo() {
		return nomeJogo;
	}

	public void setNomeJogo(String nomeJogo) {
		this.nomeJogo = nomeJogo;
	}

	public String getAnoLancamento() {
		return anoLancamento;
	}

	public void setAnoLancamento(String anoLancamento) {
		this.anoLancamento = anoLancamento;
	}

	public void setId(Long id) {
		// TODO Auto-generated method stub
		
	}

    
   
    

}
