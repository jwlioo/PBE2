package com.senai.cadastrojogos.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senai.cadastrojogos.entities.Jogadores;
import com.senai.cadastrojogos.services.JogadoresService;

@RestController
@RequestMapping("/cadastrojogadores")
public class JogadoresControllers {

    @Autowired
    private JogadoresService jogadoresService;

    // Criar um novo jogador
    @PostMapping
    public Jogadores salvar(@RequestBody Jogadores jogador) {
        return jogadoresService.salvar(jogador);
    }

    // Buscar jogador pelo ID
    @GetMapping("/{id}")
    public Jogadores buscarPorId(@PathVariable Long id) {
        return jogadoresService.buscarPorId(id);
    }

    // Excluir jogador pelo ID
    @DeleteMapping("/{id}")
    public boolean excluir(@PathVariable Long id) {
        return jogadoresService.excluir(id);
    }

   
}