package com.senai.cadastrojogos.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Jogadores {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(name = "idJogadores", nullable = false)
    private Long idJogadores;
	
	
	@Column(name = "nome")
    private String nome;

    @Column(name = "idade")
    private String idade;
	
    
    //Construtores
    
    
    public Jogadores() {
    	
    	
    }
    
    public Jogadores(Long idJogadores, String nome, String idade) {
    	this.idJogadores = idJogadores;
    	this.nome = nome;
    	this.idade = idade;
    	
    
    }
    
    
    // Getters & Setters

	public Long getId() {
		return idJogadores;
	}

	public void setId(Long id) {
		this.idJogadores = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIdade() {
		return idade;
	}

	public void setIdade(String idade) {
		this.idade = idade;
	}



}
