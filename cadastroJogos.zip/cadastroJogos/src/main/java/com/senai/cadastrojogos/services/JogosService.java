package com.senai.cadastrojogos.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senai.cadastrojogos.entities.Jogos;
import com.senai.cadastrojogos.repositories.JogosRepository;

@Service
public class JogosService {

    @Autowired
    private JogosRepository jogosRepository;

    // Salvar ou atualizar jogo
    public Jogos salvar(Jogos jogo) {
        return jogosRepository.save(jogo);
    }

    // Buscar jogo por ID
    public Jogos buscarPorId(Long id) {
        Optional<Jogos> jogo = jogosRepository.findById(id);
        return jogo.orElse(null);
    }

    // Excluir jogo
    public boolean excluir(Long id) {
        if (jogosRepository.existsById(id)) {
            jogosRepository.deleteById(id);
            return true;
        }
        return false;
    }
}