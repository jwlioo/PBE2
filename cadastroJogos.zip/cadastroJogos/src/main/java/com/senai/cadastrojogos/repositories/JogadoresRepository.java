package com.senai.cadastrojogos.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.cadastrojogos.entities.Jogadores;

public interface JogadoresRepository extends JpaRepository<Jogadores, Long> {
}