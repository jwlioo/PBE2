package com.senai.cadastrojogos.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senai.cadastrojogos.entities.Jogos;
import com.senai.cadastrojogos.services.JogosService;

@RestController
@RequestMapping("/jogos")
public class JogosControllers {

    @Autowired
    private JogosService jogosService;

    // Criar novo jogo
    @PostMapping
    public Jogos salvar(@RequestBody Jogos jogo) {
        return jogosService.salvar(jogo);
    }

    // Buscar jogo por ID
    @GetMapping("/{id}")
    public Jogos buscarPorId(@PathVariable Long id) {
        return jogosService.buscarPorId(id);
    }

    // Excluir jogo por ID
    @DeleteMapping("/{id}")
    public boolean excluir(@PathVariable Long id) {
        return jogosService.excluir(id);
    }

    // Atualizar jogo
    @PutMapping("/{id}")
    public Jogos atualizar(@PathVariable Long id, @RequestBody Jogos jogo) {
        jogo.setId(id);
        return jogosService.salvar(jogo);
    }
}