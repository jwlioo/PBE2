package com.senai.cadastroaluno.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senai.cadastroaluno.entities.Aluno;
import com.senai.cadastroaluno.repositories.AlunoRepository;

@Service
public class AlunoService {
	
	@Autowired
	private AlunoRepository alunoRepository;

	public List<Aluno> findAll() {
		return alunoRepository.findAll();
	}

	public Aluno findById(Long id) {
		return alunoRepository.findById(id).get();
	}

	public Aluno save(Aluno aluno) {
		return alunoRepository.save(aluno);
	}

	public void delete(Long id) {
		alunoRepository.deleteById(id);
	}
	
	public Aluno findByNome(String nome) {
		return alunoRepository.findByNome(nome);
	}
	
	public Aluno AutenticarPessoa(String email, String senha) {
		
		//Buscar no banco de dados um usuario que tenha um email informado.
		Aluno pessoa = alunoRepository.findByEmail(email);
		
		//Verifica se o usuario foi encontrado e se a semha informada conferi com a senha do usuariouu
		if (pessoa != null && pessoa.getSenha().equals(senha)) {
			//se email e senha estiverem corretos, retorna o objeto usuario autenticado
			return pessoa;
		} else{
			// se o usuario ´não existir ou a senha não estivar correto, retorna null(falha na altenticacao)
			return null;
		}
		
	}
}



