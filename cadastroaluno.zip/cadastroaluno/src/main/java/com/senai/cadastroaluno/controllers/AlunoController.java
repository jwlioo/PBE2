package com.senai.cadastroaluno.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.senai.cadastroaluno.entities.Aluno;
import com.senai.cadastroaluno.services.AlunoService;

@RestController
@RequestMapping("/api/alunos")
public class AlunoController {
	
	@Autowired
	private AlunoService alunoService;
	
	// listar todos os alunos
	@GetMapping
	public List<Aluno> getAll() {
		return alunoService.findAll();
	}
	// Buscar usuário por ID
		@GetMapping("/{id}")
		public Aluno getById(@PathVariable Long id) {
			return alunoService.findById(id);
		}
		
		// Criar novo aluno
		@PostMapping
		public Aluno create(@RequestBody Aluno aluno) {
			return alunoService.save(aluno);
		}
		
		// Deletar usuário por ID
		@DeleteMapping("/{id}")
		public void delete(@PathVariable Long id) {
			alunoService.delete(id);
		}

		
		//Buscar por nome 	
		@GetMapping("/buscarpornomealunos")
		public Aluno getByNome(@RequestParam String nome) {
			return alunoService.findByNome(nome);
		}
		
		@PostMapping("/login")
		public Aluno login(@RequestBody Aluno loginRequest) {
		
		//Chama o metodo de autenticação do service passando o email e senha fornecido no login
				//1. loginRequest.getEmail()- obtem o email enviado pelo usuario da requisição 
				//2. loginRequest.getSenha() - Obtem a senha enviada pelo usuario na requisição
				//3. UsuarioService.autenticarPessoa(Email, senha) -  verifica no banco se existe um usuario com este email e se a senha é valida 
				//4. Retorna o objeto usuarioautenticado, ou null caso falhe na autenticação 
				Aluno pessoa = alunoService.AutenticarPessoa(loginRequest.getEmail(), loginRequest.getSenha());
				
				//verifica se o service retornou um usuario valido "autenticação bem-sucedida"
				if (pessoa != null) {
					//se autenticado, retorna os dados do usuario
					return pessoa;
				} else {
					//se não autenticadp retorna null indicando falha no login
					return null;
				}
			}
		}
			
		



