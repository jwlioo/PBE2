package com.senai.cadastroaluno.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_alunos")
public class Aluno {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	 

	    @Column(name = "nome", nullable = false, unique = true)
	    private String nome;
	    
	    @Column(nullable = false, unique = true)
	    private String senha;
	    
	    @Column(name = "rm",nullable = false, unique = true)
	    private String rm;

	    @Column(nullable = false, unique = true)
	    private String email;
	    
	    @Column(name = "idade", nullable = false, unique = true)
	    private String idade;
	    
	    

	    // Construtor padrão (obrigatório para JPA)
	    public Aluno() {
	    }

	    // Construtor com todos os campos
	    public Aluno(Long id, String nome,String rm,String senha, String email, String idade) {
	        this.id = id;
	       this.rm = rm;
	        this.nome = nome;
	        this.senha = senha;
	        this.email = email;
	        this.idade = idade;
	    }
	    
	 // Getters & Setters 

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getSenha() {
			return senha;
		}

		public void setSenha(String senha) {
			this.senha = senha;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getIdade() {
			return idade;
		}

		public void setIdade(String idade) {
			this.idade = idade;
		}
		
		public String getRm() {
			return rm;
		}

		public void setRm(String rm) {
			this.rm = rm;
		}
	
	    
	    


}


