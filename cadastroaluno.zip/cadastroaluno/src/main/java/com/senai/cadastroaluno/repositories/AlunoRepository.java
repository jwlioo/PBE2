package com.senai.cadastroaluno.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.senai.cadastroaluno.entities.Aluno;

@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Long>{
	
	//Consulta para encontra o nome 
		Aluno findByNome(String nome);
		
		//Consulta para encontrar por email
		Aluno findByEmail(String email);
	}



